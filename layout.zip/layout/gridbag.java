import java.awt.*;
import java.applet.*;

public void gridbag extends Applet
{
	Button b1,b2,b3,b4;
	GridBagLayout g;
	GridBagConstraints gbc;
	public void init()
	{
		setLayout(new GridBagLayout());
		gbc=new GridBagConstraints();
		gbc.insets=new Insets(5,5,5,5);
		
		b1=new Button("One");
		gbc.gridx=0;
		gbc.gridy=0;
		gbc.gridheight=5;
		gbc.fill=GridBagConstraints.VERTICAL;
		add(b1,gbc);
		
		b2=new Button("Two");
		b3=new Button("Three");
		b4=new Button("Four");
		
		
	}
} 